// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'sample_response_contract.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

SampleResponseContract _$SampleResponseContractFromJson(
  Map<String, dynamic> json,
) => SampleResponseContract(
  id: json['id'] as String,
  title: json['title'] as String,
  description: json['description'] as String?,
);

Map<String, dynamic> _$SampleResponseContractToJson(
  SampleResponseContract instance,
) => <String, dynamic>{
  'id': instance.id,
  'title': instance.title,
  'description': instance.description,
};
