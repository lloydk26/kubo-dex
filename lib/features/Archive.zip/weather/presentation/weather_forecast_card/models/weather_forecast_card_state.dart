import 'package:kubo_dex/features/weather/domain/entities/weather_forecast.dart';

class WeatherForecastCardState {
  final List<DailyForecast> forecasts;
  final int selectedIndex;
  final bool isLoading;
  final bool hasError;

  const WeatherForecastCardState({
    this.forecasts = const [],
    this.selectedIndex = 0,
    this.isLoading = false,
    this.hasError = false,
  });

  WeatherForecastCardState copyWith({
    List<DailyForecast>? forecasts,
    int? selectedIndex,
    bool? isLoading,
    bool? hasError,
  }) {
    return WeatherForecastCardState(
      forecasts: forecasts ?? this.forecasts,
      selectedIndex: selectedIndex ?? this.selectedIndex,
      isLoading: isLoading ?? this.isLoading,
      hasError: hasError ?? this.hasError,
    );
  }

  DailyForecast? get selected =>
      forecasts.isEmpty ? null : forecasts[selectedIndex];

  bool get isEmpty => forecasts.isEmpty;
}
