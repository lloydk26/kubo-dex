import 'package:injectable/injectable.dart';
import 'package:kubo_dex/core/presentation/cubit/cubit_base.dart';
import 'package:kubo_dex/features/weather/domain/entities/weather_forecast.dart';
import 'package:kubo_dex/features/weather/domain/services/weather_service.dart';
import 'package:kubo_dex/features/weather/presentation/weather_forecast_card/models/weather_forecast_card_state.dart';

@injectable
class WeatherForecastCardCubit
    extends CubitBase<WeatherForecastCardState> {
  // ignore: unused_field
  final WeatherService _weatherService;

  WeatherForecastCardCubit(this._weatherService)
      : super(const WeatherForecastCardState());

  @override
  Future<void> onInitialize([Object? parameter]) async => loadForecast();

  Future<void> loadForecast() async {
    emit(state.copyWith(isLoading: true, hasError: false));
    try {
      // TODO: Replace with real API call: await _weatherService.getForecast()
      await Future.delayed(const Duration(milliseconds: 500));
      emit(state.copyWith(isLoading: false, forecasts: _mockForecasts()));
    } catch (_) {
      emit(state.copyWith(isLoading: false, hasError: true));
    }
  }

  List<DailyForecast> _mockForecasts() {
    final now = DateTime.now();
    return [
      DailyForecast(
        day: now,
        weather: 'partly_sunny',
        summary: 'Partly sunny, more clouds in the afternoon. Temperature 25/31 °C.',
        allDay: AllDayWeather(
          weather: 'partly_sunny',
          temperature: 27.5,
          temperatureMin: 25,
          temperatureMax: 30.8,
          wind: const WeatherWind(speed: 2.8, dir: 'ESE'),
        ),
      ),
      DailyForecast(
        day: now.add(const Duration(days: 1)),
        weather: 'sunny',
        summary: 'Sunny throughout the day. Temperature 26/33 °C.',
        allDay: AllDayWeather(
          weather: 'sunny',
          temperature: 29.0,
          temperatureMin: 26,
          temperatureMax: 33.0,
          wind: const WeatherWind(speed: 1.5, dir: 'NE'),
        ),
      ),
      DailyForecast(
        day: now.add(const Duration(days: 2)),
        weather: 'rain',
        summary: 'Scattered rain showers expected. Temperature 22/27 °C.',
        allDay: AllDayWeather(
          weather: 'rain',
          temperature: 24.0,
          temperatureMin: 22,
          temperatureMax: 27.0,
          wind: const WeatherWind(speed: 5.2, dir: 'SW'),
        ),
      ),
      DailyForecast(
        day: now.add(const Duration(days: 3)),
        weather: 'cloudy',
        summary: 'Overcast with light winds. Temperature 23/28 °C.',
        allDay: AllDayWeather(
          weather: 'cloudy',
          temperature: 25.5,
          temperatureMin: 23,
          temperatureMax: 28.0,
          wind: const WeatherWind(speed: 3.1, dir: 'W'),
        ),
      ),
      DailyForecast(
        day: now.add(const Duration(days: 4)),
        weather: 'thunderstorm',
        summary: 'Thunderstorms likely in the afternoon. Temperature 21/26 °C.',
        allDay: AllDayWeather(
          weather: 'thunderstorm',
          temperature: 23.0,
          temperatureMin: 21,
          temperatureMax: 26.0,
          wind: const WeatherWind(speed: 12.0, dir: 'S'),
        ),
      ),
      DailyForecast(
        day: now.add(const Duration(days: 5)),
        weather: 'partly_sunny',
        summary: 'Clearing up by midday. Temperature 24/30 °C.',
        allDay: AllDayWeather(
          weather: 'partly_sunny',
          temperature: 27.0,
          temperatureMin: 24,
          temperatureMax: 30.0,
          wind: const WeatherWind(speed: 2.0, dir: 'E'),
        ),
      ),
    ];
  }

  void selectDay(int index) {
    if (index < 0 || index >= state.forecasts.length) return;
    emit(state.copyWith(selectedIndex: index));
  }
}
