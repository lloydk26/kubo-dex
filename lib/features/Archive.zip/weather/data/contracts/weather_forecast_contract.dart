import 'package:json_annotation/json_annotation.dart';
import 'package:kubo_dex/core/data/json/json_serializable_object.dart';

part 'weather_forecast_contract.g.dart';

@JsonSerializable(fieldRename: FieldRename.snake)
class WindContract extends JsonSerializableObject {
  final double speed;
  final String dir;
  final int angle;

  const WindContract({
    required this.speed,
    required this.dir,
    required this.angle,
  });

  factory WindContract.fromJson(Map<String, dynamic> json) =>
      _$WindContractFromJson(json);

  @override
  Map<String, dynamic> toJson() => _$WindContractToJson(this);
}

@JsonSerializable(fieldRename: FieldRename.snake)
class AllDayForecastContract extends JsonSerializableObject {
  final String weather;
  final int icon;
  final double temperature;
  final double temperatureMin;
  final double temperatureMax;
  final WindContract wind;

  const AllDayForecastContract({
    required this.weather,
    required this.icon,
    required this.temperature,
    required this.temperatureMin,
    required this.temperatureMax,
    required this.wind,
  });

  factory AllDayForecastContract.fromJson(Map<String, dynamic> json) =>
      _$AllDayForecastContractFromJson(json);

  @override
  Map<String, dynamic> toJson() => _$AllDayForecastContractToJson(this);
}

@JsonSerializable(fieldRename: FieldRename.snake)
class DailyForecastContract extends JsonSerializableObject {
  final String day;
  final String weather;
  final int icon;
  final String summary;
  final AllDayForecastContract allDay;

  const DailyForecastContract({
    required this.day,
    required this.weather,
    required this.icon,
    required this.summary,
    required this.allDay,
  });

  factory DailyForecastContract.fromJson(Map<String, dynamic> json) =>
      _$DailyForecastContractFromJson(json);

  @override
  Map<String, dynamic> toJson() => _$DailyForecastContractToJson(this);
}
