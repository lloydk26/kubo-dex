// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'weather_forecast_contract.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

WindContract _$WindContractFromJson(Map<String, dynamic> json) => WindContract(
  speed: (json['speed'] as num).toDouble(),
  dir: json['dir'] as String,
  angle: (json['angle'] as num).toInt(),
);

Map<String, dynamic> _$WindContractToJson(WindContract instance) =>
    <String, dynamic>{
      'speed': instance.speed,
      'dir': instance.dir,
      'angle': instance.angle,
    };

AllDayForecastContract _$AllDayForecastContractFromJson(
  Map<String, dynamic> json,
) => AllDayForecastContract(
  weather: json['weather'] as String,
  icon: (json['icon'] as num).toInt(),
  temperature: (json['temperature'] as num).toDouble(),
  temperatureMin: (json['temperature_min'] as num).toDouble(),
  temperatureMax: (json['temperature_max'] as num).toDouble(),
  wind: WindContract.fromJson(json['wind'] as Map<String, dynamic>),
);

Map<String, dynamic> _$AllDayForecastContractToJson(
  AllDayForecastContract instance,
) => <String, dynamic>{
  'weather': instance.weather,
  'icon': instance.icon,
  'temperature': instance.temperature,
  'temperature_min': instance.temperatureMin,
  'temperature_max': instance.temperatureMax,
  'wind': instance.wind,
};

DailyForecastContract _$DailyForecastContractFromJson(
  Map<String, dynamic> json,
) => DailyForecastContract(
  day: json['day'] as String,
  weather: json['weather'] as String,
  icon: (json['icon'] as num).toInt(),
  summary: json['summary'] as String,
  allDay: AllDayForecastContract.fromJson(
    json['all_day'] as Map<String, dynamic>,
  ),
);

Map<String, dynamic> _$DailyForecastContractToJson(
  DailyForecastContract instance,
) => <String, dynamic>{
  'day': instance.day,
  'weather': instance.weather,
  'icon': instance.icon,
  'summary': instance.summary,
  'all_day': instance.allDay,
};
