import 'package:equatable/equatable.dart';

class WeatherWind extends Equatable {
  final double speed;
  final String dir;

  const WeatherWind({required this.speed, required this.dir});

  @override
  List<Object?> get props => [speed, dir];
}

class AllDayWeather extends Equatable {
  final String weather;
  final double temperature;
  final double temperatureMin;
  final double temperatureMax;
  final WeatherWind wind;

  const AllDayWeather({
    required this.weather,
    required this.temperature,
    required this.temperatureMin,
    required this.temperatureMax,
    required this.wind,
  });

  @override
  List<Object?> get props => [
        weather,
        temperature,
        temperatureMin,
        temperatureMax,
        wind,
      ];
}

class DailyForecast extends Equatable {
  final DateTime day;
  final String weather;
  final String summary;
  final AllDayWeather allDay;

  const DailyForecast({
    required this.day,
    required this.weather,
    required this.summary,
    required this.allDay,
  });

  @override
  List<Object?> get props => [day, weather, summary, allDay];
}
