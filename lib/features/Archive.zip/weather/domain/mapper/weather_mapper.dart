import 'package:injectable/injectable.dart';
import 'package:kubo_dex/features/weather/data/contracts/weather_forecast_contract.dart';
import 'package:kubo_dex/features/weather/domain/entities/weather_forecast.dart';

@injectable
class WeatherMapper {
  const WeatherMapper();

  DailyForecast toEntity(DailyForecastContract contract) {
    return DailyForecast(
      day: DateTime.parse(contract.day),
      weather: contract.weather,
      summary: contract.summary,
      allDay: _toAllDay(contract.allDay),
    );
  }

  List<DailyForecast> toEntityList(List<DailyForecastContract> contracts) =>
      contracts.map(toEntity).toList();

  AllDayWeather _toAllDay(AllDayForecastContract contract) {
    return AllDayWeather(
      weather: contract.weather,
      temperature: contract.temperature,
      temperatureMin: contract.temperatureMin,
      temperatureMax: contract.temperatureMax,
      wind: WeatherWind(speed: contract.wind.speed, dir: contract.wind.dir),
    );
  }
}
