// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'analyze_crop_response_contract.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

HealthBreakdownContract _$HealthBreakdownContractFromJson(
  Map<String, dynamic> json,
) => HealthBreakdownContract(
  foliage: (json['foliage'] as num).toInt(),
  stem: (json['stem'] as num).toInt(),
  coloration: (json['coloration'] as num).toInt(),
);

Map<String, dynamic> _$HealthBreakdownContractToJson(
  HealthBreakdownContract instance,
) => <String, dynamic>{
  'foliage': instance.foliage,
  'stem': instance.stem,
  'coloration': instance.coloration,
};

HealthDetailContract _$HealthDetailContractFromJson(
  Map<String, dynamic> json,
) => HealthDetailContract(
  status: json['status'] as String,
  isHealthy: json['is_healthy'] as bool,
  condition: json['condition'] as String?,
  diseaseConfidencePct: (json['disease_confidence_pct'] as num?)?.toDouble(),
  cropConfidencePct: (json['crop_confidence_pct'] as num).toDouble(),
  breakdown: json['breakdown'] == null
      ? null
      : HealthBreakdownContract.fromJson(
          json['breakdown'] as Map<String, dynamic>,
        ),
);

Map<String, dynamic> _$HealthDetailContractToJson(
  HealthDetailContract instance,
) => <String, dynamic>{
  'status': instance.status,
  'is_healthy': instance.isHealthy,
  'condition': instance.condition,
  'disease_confidence_pct': instance.diseaseConfidencePct,
  'crop_confidence_pct': instance.cropConfidencePct,
  'breakdown': instance.breakdown,
};

HealthDataContract _$HealthDataContractFromJson(Map<String, dynamic> json) =>
    HealthDataContract(
      score: (json['score'] as num).toInt(),
      data: HealthDetailContract.fromJson(json['data'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$HealthDataContractToJson(HealthDataContract instance) =>
    <String, dynamic>{'score': instance.score, 'data': instance.data};

AnalyzeCropResponseContract _$AnalyzeCropResponseContractFromJson(
  Map<String, dynamic> json,
) => AnalyzeCropResponseContract(
  confidence: (json['confidence'] as num).toDouble(),
  image: json['image'] as String,
  name: json['name'] as String,
  type: (json['type'] as List<dynamic>).map((e) => e as String).toList(),
  description: json['description'] as String,
  health: HealthDataContract.fromJson(json['health'] as Map<String, dynamic>),
  recommendation: (json['recommendation'] as List<dynamic>)
      .map((e) => e as String)
      .toList(),
);

Map<String, dynamic> _$AnalyzeCropResponseContractToJson(
  AnalyzeCropResponseContract instance,
) => <String, dynamic>{
  'confidence': instance.confidence,
  'image': instance.image,
  'name': instance.name,
  'type': instance.type,
  'description': instance.description,
  'health': instance.health,
  'recommendation': instance.recommendation,
};
